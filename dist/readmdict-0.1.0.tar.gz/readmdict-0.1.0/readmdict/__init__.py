"""Init."""
from .readmdict import MDX, MDD


__version__ = "0.1.0"
VERSION = __version__.split(".")
__all__ = ("readmdict", "MDX", "MDD")
